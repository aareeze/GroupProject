package com.shashank.platform.carrental;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class Booking extends AppCompatActivity {


    private TextView booklink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        booklink = findViewById(R.id.booklink);
        booklink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openLink();
            }
        });

    }

    private void openLink() {
        Intent intent = new Intent(this, Confirmation.class);
        startActivity(intent);
    }


}

