package com.shashank.platform.carrental;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView bookn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bookn = findViewById(R.id.bookn);
        bookn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openBook();
            }
        });
    }

    private void openBook() {
        Intent intent = new Intent(this, Booking.class);
        startActivity(intent);
    }
}
